from django.apps import AppConfig


class SkintoneConfig(AppConfig):
    name = 'skintone'
